﻿#if SELF_TEST
using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
internal sealed partial class PlayerWindow {
    async Task Verify(bool navigation){
        var log=new StringBuilder();Action<string,bool> check=(name,ok)=>{log.AppendLine(name+"="+ok);};
        check("NavigationSuccess",navigation);check("DpiAware",GetAwarenessFromDpiAwarenessContext(GetWindowDpiAwarenessContext(Handle))==2);check("CompactTitlebar",titlebar.Height==Px(36));
        Rectangle initial=Bounds;bool pin=TopMost;SetFullscreen(true);await Task.Delay(500);Rectangle screen=Screen.FromControl(this).Bounds;IntPtr bottom=WindowFromPoint(new Point(screen.Left+screen.Width/2,screen.Bottom-2));
        check("NativeFullscreen",fullscreen&&Bounds==screen&&!titlebar.Visible&&!tabbar.Visible);check("CoversTaskbarArea",bottom==Handle||IsChild(Handle,bottom));SetFullscreen(false);check("FullscreenRestores",Bounds==initial&&TopMost==pin);
        await web.CoreWebView2.CallDevToolsProtocolMethodAsync("Runtime.evaluate","{\"expression\":\"document.documentElement.requestFullscreen()\",\"userGesture\":true,\"awaitPromise\":true}");await Task.Delay(500);check("VideoFullscreen",fullscreen&&web.CoreWebView2.ContainsFullScreenElement&&!titlebar.Visible&&!tabbar.Visible);await web.CoreWebView2.ExecuteScriptAsync("document.exitFullscreen()");await Task.Delay(300);check("VideoExitRestores",!fullscreen&&Bounds==initial);
        web.ZoomFactor=1.1;SaveSettings();var saved=LoadSettings(settingsPath);check("ZoomPersists",Math.Abs(saved.Zoom-1.1)<.001);check("WindowPersists",saved.Width==initial.Width&&saved.Height==initial.Height);web.ZoomFactor=1;settings.Zoom=1;
        await web.CoreWebView2.ExecuteScriptAsync("history.pushState(null,'',location.href.split('#')[0]+'#minimal-shell-back-test')");await Task.Delay(350);check("BackButtonEnabled",titlebar.BackEnabled);titlebar.PressBack();await Task.Delay(350);check("BackButtonNavigates",await web.CoreWebView2.ExecuteScriptAsync("location.hash!=='#minimal-shell-back-test'")=="true");
        ShowMenu();await Task.Delay(300);check("MenuAvailable",menu.Visible&&menu.Items.Count>=8);
        var zoomMenu=(ToolStripMenuItem)menu.Items[5];zoomMenu.ShowDropDown();await Task.Delay(200);RECT parentNative,childNative;GetWindowRect(menu.Handle,out parentNative);GetWindowRect(zoomMenu.DropDown.Handle,out childNative);Rectangle parentMenu=Rectangle.FromLTRB(parentNative.Left,parentNative.Top,parentNative.Right,parentNative.Bottom);Rectangle childMenu=Rectangle.FromLTRB(childNative.Left,childNative.Top,childNative.Right,childNative.Bottom);check("ZoomSubmenuAttached",Math.Abs(childMenu.Left-parentMenu.Right)<=1||Math.Abs(childMenu.Right-parentMenu.Left)<=1);zoomMenu.HideDropDown();menu.Close();
        using(var image=File.Create(Path.Combine(reportDir,"web-preview.png")))await web.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png,image);
        string page=await web.CoreWebView2.ExecuteScriptAsync("JSON.stringify({url:location.href,title:document.title,dpr:devicePixelRatio,app:'Frameleaf'})");log.AppendLine("Page="+page);
        check("ClientDownloadNotBlocked",AllowedPage("https://app.bilibili.com/")&&AllowedPage("https://www.bilibili.com/blackboard/desktop-download.html"));
        await web.CoreWebView2.ExecuteScriptAsync("(()=>{const a=document.createElement('a');a.id='public-promotion-test';a.href='https://app.bilibili.com/';a.textContent='下载客户端';document.body.appendChild(a)})()");await Task.Delay(500);
        check("ClientPromotionVisible",await web.CoreWebView2.ExecuteScriptAsync("getComputedStyle(document.getElementById('public-promotion-test')).display!=='none'")=="true");
        await web.CoreWebView2.ExecuteScriptAsync("document.getElementById('public-promotion-test').remove()");
        await VerifyTabs(check);
        File.WriteAllText(Path.Combine(reportDir,"test-result.txt"),log.ToString());Close();
    }
    async Task WaitDocument(BrowserTab tab){for(int i=0;i<80&&Live(tab);i++){try{if(await tab.View.CoreWebView2.ExecuteScriptAsync("document.readyState==='complete'")=="true")return;}catch{}await Task.Delay(100);}throw new Exception("测试页面加载超时");}
    async Task VerifyTabs(Action<string,bool> check){
        BrowserTab homeTab=activeTab;int initial=tabs.Count;
        var first=await CreateTabAsync("about:blank",true);await WaitDocument(first);
        await first.View.CoreWebView2.ExecuteScriptAsync("document.title='独立标签 A';history.pushState(null,'','#page-a');window.savedPagePosition=245");await Task.Delay(200);
        check("NewTabButtonAvailable",tabbar.NewTabButtonAvailable);
        check("TabsCreate",tabs.Count==initial+1&&activeTab==first&&first.View.Visible&&tabbar.Visible);
        check("TabTitleUpdates",first.Title=="独立标签 A");
        await first.View.CoreWebView2.CallDevToolsProtocolMethodAsync("Runtime.evaluate","{\"expression\":\"(async()=>{const c=document.createElement('canvas');c.width=64;c.height=64;document.body.appendChild(c);c.getContext('2d').fillRect(0,0,64,64);const v=document.createElement('video');v.id='tab-test-video';v.muted=true;v.srcObject=c.captureStream(10);setInterval(()=>c.getContext('2d').fillRect(0,0,64,64),100);document.body.appendChild(v);await v.play();return !v.paused})()\",\"userGesture\":true,\"awaitPromise\":true}");
        check("TabVideoStarted",await first.View.CoreWebView2.ExecuteScriptAsync("!document.getElementById('tab-test-video').paused")=="true");
        var second=await CreateTabAsync("about:blank",true);await WaitDocument(second);await Task.Delay(300);
        check("TabsSwitch",activeTab==second&&second.View.Visible&&!first.View.Visible);
        check("BackgroundVideoPaused",await first.View.CoreWebView2.ExecuteScriptAsync("document.getElementById('tab-test-video').paused")=="true"&&first.View.CoreWebView2.IsMuted);
        check("TabHistoryIndependent",!second.View.CanGoBack&&first.View.CanGoBack);
        ActivateTab(first);await Task.Delay(250);check("TabPageRetained",await web.CoreWebView2.ExecuteScriptAsync("location.hash==='#page-a'&&window.savedPagePosition===245")=="true");
        check("SwitchDoesNotAutoPlay",await web.CoreWebView2.ExecuteScriptAsync("document.getElementById('tab-test-video').paused")=="true"&&!web.CoreWebView2.IsMuted);
        var cookie=web.CoreWebView2.CookieManager.CreateCookie("minimal_tabs_smoke","shared",".bilibili.com","/");web.CoreWebView2.CookieManager.AddOrUpdateCookie(cookie);
        var shared=await second.View.CoreWebView2.CookieManager.GetCookiesAsync(Home);check("TabsShareLoginProfile",shared.Any(c=>c.Name=="minimal_tabs_smoke"&&c.Value=="shared"));web.CoreWebView2.CookieManager.DeleteCookie(cookie);
        SetFullscreen(true);check("TabsHiddenFullscreen",!tabbar.Visible&&!titlebar.Visible);SetFullscreen(false);check("TabsRestoreFullscreen",tabbar.Visible&&titlebar.Visible);
        await CloseTabAsync(second);check("CloseBackgroundTab",activeTab==first&&tabs.Count==initial+1&&second.View.IsDisposed);
        await CloseTabAsync(first);check("CloseActiveTab",activeTab==homeTab&&tabs.Count==initial&&first.View.IsDisposed);
        // Exercise actual captured link clicks and native window.open from a trusted page.
        int before=tabs.Count;
        await homeTab.View.CoreWebView2.ExecuteScriptAsync("(()=>{const a=document.createElement('a');a.id='tabs-link-test';a.href='https://www.bilibili.com/video/BV1xx411c7mD/';a.textContent='tab test';document.body.appendChild(a);a.click();a.remove()})()");
        for(int i=0;i<50&&tabs.Count==before;i++)await Task.Delay(100);
        check("VideoClickOpensTab",tabs.Count==before+1&&activeTab!=homeTab);
        if(activeTab!=homeTab)await CloseTabAsync(activeTab);
        before=tabs.Count;
        await homeTab.View.CoreWebView2.ExecuteScriptAsync("(()=>{const a=document.createElement('a');a.href='https://www.bilibili.com/video/BV1xx411c7mD/';document.body.appendChild(a);a.dispatchEvent(new MouseEvent('auxclick',{button:1,bubbles:true,cancelable:true}));a.remove()})()");
        for(int i=0;i<50&&tabs.Count==before;i++)await Task.Delay(100);
        check("MiddleClickBackgroundTab",tabs.Count==before+1&&activeTab==homeTab);
        foreach(var tab in tabs.ToArray())if(tab!=homeTab)await CloseTabAsync(tab);
        await homeTab.View.CoreWebView2.CallDevToolsProtocolMethodAsync("Runtime.evaluate","{\"expression\":\"window.open('about:blank')\",\"userGesture\":true}");
        await Task.Delay(300);check("NonWebPopupNotOpened",tabs.Count==initial);
        before=tabs.Count;
        await homeTab.View.CoreWebView2.CallDevToolsProtocolMethodAsync("Runtime.evaluate","{\"expression\":\"window.open('https://www.bilibili.com/')\",\"userGesture\":true}");
        for(int i=0;i<50&&tabs.Count==before;i++)await Task.Delay(100);
        check("NativePopupOpensTab",tabs.Count==before+1&&activeTab!=homeTab);foreach(var tab in tabs.ToArray())if(tab!=homeTab)await CloseTabAsync(tab);
        Rectangle windowBefore=Bounds;Bounds=new Rectangle(Left,Top,Px(680),Px(500));
        for(int i=0;i<8;i++)await CreateTabAsync("about:blank",true);
        check("OverflowKeepsActiveTabReachable",tabbar.OverflowAvailable&&tabbar.ActiveTabReachable&&tabbar.NewTabButtonAvailable);
        ActivateTab(homeTab);check("OverflowReachesFirstTab",tabbar.ActiveTabReachable);
        foreach(var tab in tabs.ToArray())if(tab!=homeTab)await CloseTabAsync(tab);Bounds=windowBefore;
        await CloseTabAsync(homeTab);check("ClosingLastTabKeepsHome",tabs.Count==1&&activeTab!=homeTab&&homeTab.View.IsDisposed);
        check("TabsBelowTitlebar",tabbar.Top>=titlebar.Bottom&&browserHost.Top>=tabbar.Bottom);
    }

}
#endif
