﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.8")]
[assembly: System.Reflection.AssemblyVersion("0.1.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("0.1.0.0")]
[assembly: System.Reflection.AssemblyTitle("Frameleaf")]
[assembly: System.Reflection.AssemblyDescription("Lightweight tabbed web video window")]
[assembly: System.Reflection.AssemblyProduct("Frameleaf")]

[DataContract] public sealed class WindowSettings {
    [DataMember] public bool Remember = true;
    [DataMember] public int X, Y, Width, Height;
    [DataMember] public bool Maximized;
    [DataMember] public double Zoom = 1;
}

internal sealed partial class PlayerWindow : Form {
    const string AppName="Frameleaf", DataName="Frameleaf.PublicPreview", IconName="Frameleaf.ico";
    static readonly string Home=ReadHomeUrl();
    const bool Light=true;
    readonly WebView2 initialWeb=new WebView2();
    WebView2 web {get{return activeTab==null?initialWeb:activeTab.View;}}
    readonly ChromeBar titlebar;
    readonly ContextMenuStrip menu=new ContextMenuStrip();
    readonly bool smoke;
    readonly string reportDir, settingsPath;
    WindowSettings settings;
    bool fullscreen, fullscreenFromPage, oldTopMost;
#if SELF_TEST
    bool testing;
#endif
    Rectangle fullBounds;
    FormWindowState fullState;
    readonly Color surface=Light?Color.FromArgb(250,250,252):Color.FromArgb(25,27,33);
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h,int a,ref int v,int s);
    [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr c);
    [DllImport("user32.dll")] static extern uint GetDpiForWindow(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr GetWindowDpiAwarenessContext(IntPtr h);
    [DllImport("user32.dll")] static extern int GetAwarenessFromDpiAwarenessContext(IntPtr c);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h,IntPtr a,int x,int y,int w,int z,uint flags);
    [StructLayout(LayoutKind.Sequential)] struct RECT {public int Left,Top,Right,Bottom;}
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h,out RECT rect);
    [DllImport("user32.dll")] static extern bool ReleaseCapture();
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,IntPtr l);
    [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(Point p);
    [DllImport("user32.dll")] static extern bool IsChild(IntPtr p,IntPtr c);
    [StructLayout(LayoutKind.Sequential)] struct MINMAXINFO { public Point Reserved,MaxSize,MaxPosition,MinTrackSize,MaxTrackSize; }
    public int Px(int value) { return (int)Math.Round(value*DeviceDpi/96.0); }
    public PlayerWindow(bool test,string reports) {
        smoke=test; reportDir=reports;
        string data=smoke?Path.Combine(reportDir,"test-data"):Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),DataName);
        Directory.CreateDirectory(data);
        settingsPath=Path.Combine(data,"window-settings.json"); settings=LoadSettings(settingsPath);
        AutoScaleDimensions=new SizeF(96,96); AutoScaleMode=AutoScaleMode.Dpi;
        Text=AppName+" · 帧页"; Icon=new Icon(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,IconName));
        BackColor=surface; Size=new Size(Light?1440:1280,900); MinimumSize=new Size(680,480);
        StartPosition=FormStartPosition.CenterScreen; KeyPreview=true;
        titlebar=new ChromeBar(this,Light,AppName); titlebar.Dock=DockStyle.Top; titlebar.Height=36;
        activeTab=new BrowserTab(initialWeb);tabs.Add(activeTab);
        tabbar=new BrowserTabBar(this);tabbar.Dock=DockStyle.Top;tabbar.Height=40;
        web.Dock=DockStyle.Fill;web.DefaultBackgroundColor=Color.White;
        browserHost.Dock=DockStyle.Fill;browserHost.Controls.Add(web);
        Controls.Add(browserHost);Controls.Add(tabbar);Controls.Add(titlebar);Padding=new Padding(1);tabbar.RefreshTabs();
        menu.Font=new Font("Microsoft YaHei UI",9f); menu.ShowImageMargin=false; menu.ShowCheckMargin=true;
        menu.BackColor=surface; menu.ForeColor=Light?Color.FromArgb(45,47,52):Color.Gainsboro;
        menu.Renderer=new QuietMenuRenderer(Light);
        if(settings.Remember&&settings.Width>=680&&settings.Height>=480) {
            Rectangle saved=new Rectangle(settings.X,settings.Y,settings.Width,settings.Height);
            foreach(Screen screen in Screen.AllScreens) if(Rectangle.Intersect(saved,screen.WorkingArea).Width>=150&&Rectangle.Intersect(saved,screen.WorkingArea).Height>=100) {
                StartPosition=FormStartPosition.Manual; Bounds=saved; break;
            }
            if(settings.Maximized) WindowState=FormWindowState.Maximized;
        }
        KeyDown+=HandleShellKey;
        MouseDown+=delegate(object sender,MouseEventArgs e){if(e.Button==MouseButtons.XButton1&&web.CanGoBack)web.GoBack();else if(e.Button==MouseButtons.XButton2&&web.CanGoForward)web.GoForward();};
        Activated+=delegate {if(fullscreen)TopMost=true;}; Deactivate+=delegate {if(fullscreen)TopMost=false;};
        Resize+=delegate {if(titlebar!=null)titlebar.Invalidate();};
        DpiChanged+=delegate { LayoutChrome(); };
        FormClosing+=delegate {SaveSettings();};
        Shown+=async delegate { LayoutChrome(); ApplyMaterial(); await Initialize(); };
    }
    async void HandleShellKey(object sender,KeyEventArgs e) {
        if(e.Handled)return;
        if(e.Control&&!e.Shift&&e.KeyCode==Keys.T){e.Handled=true;e.SuppressKeyPress=true;await CreateTabAsync(Home,true);}
        else if(e.Control&&e.KeyCode==Keys.W){e.Handled=true;e.SuppressKeyPress=true;await CloseTabAsync(activeTab);}
        else if(e.Control&&e.KeyCode==Keys.Tab){e.Handled=true;e.SuppressKeyPress=true;int index=tabs.IndexOf(activeTab);ActivateTab(tabs[(index+(e.Shift?tabs.Count-1:1))%tabs.Count]);}
        else if(e.KeyCode==Keys.F11) {e.Handled=true;e.SuppressKeyPress=true;await ToggleFullscreen();}
        else if(e.KeyCode==Keys.Escape&&fullscreen){e.Handled=true;e.SuppressKeyPress=true;await LeaveFullscreen();}
        else if(e.Control&&e.Shift&&e.KeyCode==Keys.T){e.Handled=true;e.SuppressKeyPress=true;TopMost=!TopMost;titlebar.Invalidate();}
        else if(e.Alt&&e.KeyCode==Keys.Left){e.Handled=true;e.SuppressKeyPress=true;if(web.CanGoBack)web.GoBack();}
        else if(e.Alt&&e.KeyCode==Keys.Right){e.Handled=true;e.SuppressKeyPress=true;if(web.CanGoForward)web.GoForward();}
        else if(e.Alt&&e.KeyCode==Keys.Home){e.Handled=true;e.SuppressKeyPress=true;web.Source=new Uri(Home);}
    }
    void LayoutChrome() { titlebar.Height=Px(36);tabbar.Height=Px(40);tabbar.Visible=!fullscreen;tabbar.RefreshTabs(); Padding=fullscreen?Padding.Empty:new Padding(1); titlebar.UpdateNavigation(); }
    void ApplyMaterial() {
        int dark=Light?0:1, rounded=2, border=Light?0x00DDDDDD:0x003C3935;
        DwmSetWindowAttribute(Handle,20,ref dark,4); DwmSetWindowAttribute(Handle,33,ref rounded,4); DwmSetWindowAttribute(Handle,34,ref border,4);
    }
    protected override void WndProc(ref Message m) {
        if(m.Msg==0x83&&m.WParam!=IntPtr.Zero) {m.Result=IntPtr.Zero;return;}
        if(m.Msg==0x24) {
            base.WndProc(ref m); var info=(MINMAXINFO)Marshal.PtrToStructure(m.LParam,typeof(MINMAXINFO));
            Screen s=Screen.FromHandle(Handle); info.MaxPosition=new Point(s.WorkingArea.Left-s.Bounds.Left,s.WorkingArea.Top-s.Bounds.Top);info.MaxSize=new Point(s.WorkingArea.Width,s.WorkingArea.Height);
            Marshal.StructureToPtr(info,m.LParam,false);return;
        }
        if(m.Msg==0x84&&!fullscreen&&WindowState==FormWindowState.Normal) {
            long pos=m.LParam.ToInt64(); Point p=PointToClient(new Point((short)(pos&65535),(short)((pos>>16)&65535)));int e=Px(6);
            bool left=p.X<e,right=p.X>=ClientSize.Width-e,top=p.Y<e,bottom=p.Y>=ClientSize.Height-e;
            if(left||right||top||bottom){m.Result=new IntPtr(top?(left?13:right?14:12):bottom?(left?16:right?17:15):left?10:11);return;}
        }
        base.WndProc(ref m);
    }
    public void DragWindow() {if(fullscreen)return;ReleaseCapture();SendMessage(Handle,0xA1,new IntPtr(2),IntPtr.Zero);}
    public void ToggleMaximize() {if(!fullscreen)WindowState=WindowState==FormWindowState.Maximized?FormWindowState.Normal:FormWindowState.Maximized;}
    public void ShowMenu() {
        menu.Items.Clear();
        AddMenu("首页", "Alt+Home",delegate{web.Source=new Uri(Home);},false,web.CoreWebView2!=null);
        AddMenu("刷新", "F5",delegate{if(web.CoreWebView2!=null)web.Reload();},false,web.CoreWebView2!=null);
        menu.Items.Add(new ToolStripSeparator());
        AddMenu("窗口置顶", "Ctrl+Shift+T",delegate{TopMost=!TopMost;titlebar.Invalidate();},TopMost,true);
        menu.Items.Add(new ToolStripSeparator());
        var zoom=new ToolStripMenuItem("页面缩放（"+Math.Round(web.ZoomFactor*100)+"%）");
        foreach(int percent in new int[]{75,90,100,110,125,150}){int chosen=percent;var z=new ToolStripMenuItem(percent+"%"){Checked=Math.Abs(web.ZoomFactor-percent/100.0)<.001,AutoSize=false,Size=new Size(Px(128),Px(32))};z.Click+=delegate{web.ZoomFactor=chosen/100.0;SaveSettings();};zoom.DropDownItems.Add(z);}
        zoom.DropDown.BackColor=surface;zoom.DropDown.ForeColor=menu.ForeColor;zoom.DropDown.Font=menu.Font;zoom.DropDown.Renderer=menu.Renderer;
        zoom.DropDownOpened+=delegate{BeginInvoke(new Action(delegate{if(zoom.DropDown.Visible)AttachSubmenu(zoom);}));};
        menu.Items.Add(zoom);
        AddMenu("记住窗口位置", "",delegate{settings.Remember=!settings.Remember;SaveSettings();},settings.Remember,true);
        var fs=new ToolStripMenuItem(fullscreen?"退出全屏":"全屏"){ShortcutKeyDisplayString="F11"};fs.Click+=async delegate{await ToggleFullscreen();};menu.Items.Add(fs);
        foreach(ToolStripItem item in menu.Items)if(!(item is ToolStripSeparator)){item.AutoSize=false;item.Size=new Size(Px(256),Px(32));}
        menu.Show(titlebar,new Point(Math.Max(0,titlebar.Width-Px(388)),titlebar.Height));
    }
    void AttachSubmenu(ToolStripMenuItem item){
        ToolStripDropDown child=item.DropDown;RECT nativeParent;GetWindowRect(item.Owner.Handle,out nativeParent);Rectangle parent=Rectangle.FromLTRB(nativeParent.Left,nativeParent.Top,nativeParent.Right,nativeParent.Bottom);Rectangle work=Screen.FromRectangle(parent).WorkingArea;
        int x=parent.Right-1;if(x+child.Width>work.Right)x=parent.Left-child.Width+1;
        int y=Math.Max(work.Top,Math.Min(parent.Top+item.Bounds.Top,work.Bottom-child.Height));SetWindowPos(child.Handle,IntPtr.Zero,x,y,0,0,0x15);

    }
    void AddMenu(string text,string shortcut,Action action,bool check,bool enabled){var i=new ToolStripMenuItem(text){ShortcutKeyDisplayString=shortcut,Checked=check,Enabled=enabled};i.Click+=delegate{action();};menu.Items.Add(i);}
    async Task Initialize(){
        try{string data=smoke?Path.Combine(reportDir,"test-profile"):Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),DataName,"Profile");
            browserEnvironment=await CoreWebView2Environment.CreateAsync(null,data);activeTab.Ready=InitializeBrowser(activeTab,Home);await activeTab.Ready;
        }catch(Exception ex){Directory.CreateDirectory(reportDir);File.WriteAllText(Path.Combine(reportDir,"startup-error.txt"),ex.ToString());if(smoke)Close();else MessageBox.Show("网页组件启动失败。请检查 Microsoft WebView2 Runtime 是否已安装，然后重新打开。\n"+ex.Message,AppName);}
    }
    async Task ToggleFullscreen(){if(fullscreen)await LeaveFullscreen();else{fullscreenFromPage=false;SetFullscreen(true);}}
    async Task LeaveFullscreen(){if(web.CoreWebView2!=null&&web.CoreWebView2.ContainsFullScreenElement)await web.CoreWebView2.ExecuteScriptAsync("document.exitFullscreen()");fullscreenFromPage=false;SetFullscreen(false);}
    void SetFullscreen(bool enabled){if(fullscreen==enabled)return;
        if(enabled){Screen s=Screen.FromControl(this);fullBounds=WindowState==FormWindowState.Normal?Bounds:RestoreBounds;fullState=WindowState;oldTopMost=TopMost;fullscreen=true;WindowState=FormWindowState.Normal;titlebar.Visible=false;tabbar.Visible=false;Padding=Padding.Empty;TopMost=true;Bounds=s.Bounds;SetWindowPos(Handle,new IntPtr(-1),s.Bounds.X,s.Bounds.Y,s.Bounds.Width,s.Bounds.Height,0x60);BringToFront();}
        else{fullscreen=false;TopMost=oldTopMost;titlebar.Visible=true;Padding=new Padding(1);Bounds=fullBounds;WindowState=fullState;LayoutChrome();titlebar.Invalidate();}
    }
    [DataContract] sealed class AppConfiguration{[DataMember(Name="homeUrl")]public string HomeUrl {get;set;}}
    static string ReadHomeUrl(){
        const string fallback="https://www.bilibili.com/";
        try{using(var file=File.OpenRead(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Frameleaf.json"))){var config=(AppConfiguration)new DataContractJsonSerializer(typeof(AppConfiguration)).ReadObject(file);Uri uri;if(config!=null&&Uri.TryCreate(config.HomeUrl,UriKind.Absolute,out uri)&&(uri.Scheme=="https"||uri.Scheme=="http")&&string.IsNullOrEmpty(uri.UserInfo))return uri.AbsoluteUri;}}catch{}return fallback;
    }
    static WindowSettings LoadSettings(string path){try{using(var file=File.OpenRead(path))return (WindowSettings)new DataContractJsonSerializer(typeof(WindowSettings)).ReadObject(file);}catch{return new WindowSettings();}}
    void SaveSettings(){try{
        Rectangle r=fullscreen?fullBounds:WindowState==FormWindowState.Normal?Bounds:RestoreBounds;
        settings.X=r.X;settings.Y=r.Y;settings.Width=r.Width;settings.Height=r.Height;settings.Maximized=(fullscreen?fullState:WindowState)==FormWindowState.Maximized;
        if(web.CoreWebView2!=null)settings.Zoom=web.ZoomFactor;
        using(var memory=new MemoryStream()){new DataContractJsonSerializer(typeof(WindowSettings)).WriteObject(memory,settings);File.WriteAllBytes(settingsPath,memory.ToArray());}
    }catch{}}
    sealed class QuietMenuRenderer:ToolStripProfessionalRenderer{
        readonly bool light; public QuietMenuRenderer(bool value){light=value;RoundedEdges=false;}
        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e){if(e.Item.Selected)using(var brush=new SolidBrush(light?Color.FromArgb(236,237,241):Color.FromArgb(48,51,60)))e.Graphics.FillRectangle(brush,new Rectangle(3,1,e.Item.Width-6,e.Item.Height-2));}
        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e){using(var p=new Pen(light?Color.FromArgb(218,220,225):Color.FromArgb(64,67,76)))e.Graphics.DrawRectangle(p,0,0,e.ToolStrip.Width-1,e.ToolStrip.Height-1);}
        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e){
            Rectangle rect=e.TextRectangle;rect.Y=0;rect.Height=e.Item.Height;
            TextFormatFlags flags=TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.NoPrefix|TextFormatFlags.NoPadding;
            flags|=(e.TextFormat&TextFormatFlags.Right)==TextFormatFlags.Right?TextFormatFlags.Right:TextFormatFlags.Left;
            TextRenderer.DrawText(e.Graphics,e.Text,e.TextFont,rect,e.Item.Enabled?e.TextColor:Color.Gray,flags);
        }
        protected override void OnRenderImageMargin(ToolStripRenderEventArgs e){using(var brush=new SolidBrush(e.ToolStrip.BackColor))e.Graphics.FillRectangle(brush,e.AffectedBounds);}
        protected override void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e){
            float scale=e.ToolStrip.DeviceDpi/96f;float cx=e.ImageRectangle.Left+e.ImageRectangle.Width/2f,cy=e.Item.Height/2f;
            e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;using(var pen=new Pen(light?Color.FromArgb(65,69,78):Color.Gainsboro,1.6f*scale))e.Graphics.DrawLines(pen,new PointF[]{new PointF(cx-4*scale,cy),new PointF(cx-scale,cy+3*scale),new PointF(cx+5*scale,cy-4*scale)});
        }
    }
    sealed class ChromeBar:Control{
        readonly PlayerWindow owner; readonly bool light;readonly string name;readonly NavigationButton back;int hover=-1;
        public ChromeBar(PlayerWindow form,bool theme,string title){owner=form;light=theme;name=title;DoubleBuffered=true;SetStyle(ControlStyles.ResizeRedraw,true);BackColor=form.surface;back=new NavigationButton(form,theme);back.Click+=delegate{if(owner.web.CanGoBack)owner.web.GoBack();};Controls.Add(back);}
        public bool BackEnabled {get{return back.Enabled;}}
        public void PressBack(){back.PerformClick();}
        public void UpdateNavigation(){back.Visible=true;back.Enabled=owner.web.CoreWebView2!=null&&owner.web.CanGoBack;PerformLayout();}
        protected override void OnLayout(LayoutEventArgs e){base.OnLayout(e);if(back!=null)back.Bounds=new Rectangle(Width-owner.Px(220),(Height-owner.Px(28))/2,owner.Px(44),owner.Px(28));}
        int Hit(int x){int size=owner.Px(44);int n=(Width-x)/size;return n>=0&&n<4?n:-1;}
        protected override void OnMouseMove(MouseEventArgs e){int h=Hit(e.X);if(h!=hover){hover=h;Invalidate();}base.OnMouseMove(e);}
        protected override void OnMouseLeave(EventArgs e){hover=-1;Invalidate();base.OnMouseLeave(e);}
        protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(e.Button==MouseButtons.Left&&Hit(e.X)<0&&e.Clicks==1)owner.DragWindow();}
        protected override void OnMouseDoubleClick(MouseEventArgs e){if(e.Button==MouseButtons.Left&&Hit(e.X)<0)owner.ToggleMaximize();base.OnMouseDoubleClick(e);}
        protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);if(e.Button!=MouseButtons.Left)return;switch(Hit(e.X)){case 0:owner.Close();break;case 1:owner.ToggleMaximize();break;case 2:owner.WindowState=FormWindowState.Minimized;break;case 3:owner.ShowMenu();break;}}
        protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);Graphics g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;int s=owner.Px(44),cy=Height/2;Color ink=light?Color.FromArgb(44,47,54):Color.FromArgb(225,226,232);
            if(hover>=0){using(var b=new SolidBrush(hover==0?Color.FromArgb(215,49,60):light?Color.FromArgb(235,236,240):Color.FromArgb(45,48,57)))g.FillRectangle(b,Width-(hover+1)*s,0,s,Height);}
            int icon=owner.Px(18),iconX=owner.Px(14),textX=owner.Px(40);g.DrawIcon(owner.Icon,new Rectangle(iconX,cy-icon/2,icon,icon));
            using(var f=new Font("Microsoft YaHei UI",9f))using(var b=new SolidBrush(ink))g.DrawString(name,f,b,new PointF(textX,cy-f.GetHeight(g)/2));
            if(owner.TopMost){using(var b=new SolidBrush(light?Color.FromArgb(82,105,218):Color.FromArgb(44,215,210)))g.FillEllipse(b,textX+TextRenderer.MeasureText(name,Font).Width+owner.Px(12),cy-owner.Px(2),owner.Px(4),owner.Px(4));}
            for(int i=0;i<4;i++){int cx=Width-s*i-s/2;using(var p=new Pen(i==0&&hover==0?Color.White:ink,Math.Max(1,owner.Px(1)))){int r=owner.Px(4);if(i==0){g.DrawLine(p,cx-r,cy-r,cx+r,cy+r);g.DrawLine(p,cx+r,cy-r,cx-r,cy+r);}else if(i==1){g.DrawRectangle(p,cx-r,cy-r,r*2,r*2);}else if(i==2){g.DrawLine(p,cx-r,cy,cx+r,cy);}else{using(var b=new SolidBrush(ink))for(int n=-1;n<=1;n++)g.FillEllipse(b,cx+n*owner.Px(4)-1,cy-1,2,2);}}}
            using(var p=new Pen(light?Color.FromArgb(235,236,240):Color.FromArgb(43,46,54)))g.DrawLine(p,0,Height-1,Width,Height-1);
        }
        sealed class NavigationButton:Button{
            readonly PlayerWindow owner;readonly bool light;bool over;
            public NavigationButton(PlayerWindow form,bool theme){owner=form;light=theme;AccessibleName="返回";AccessibleDescription="返回上一页（Alt+左方向键）";AccessibleRole=AccessibleRole.PushButton;Cursor=Cursors.Hand;TabStop=true;FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;SetStyle(ControlStyles.OptimizedDoubleBuffer,true);var tip=new ToolTip();tip.SetToolTip(this,"返回（Alt+←）");}
            protected override void OnMouseEnter(EventArgs e){over=true;Invalidate();base.OnMouseEnter(e);}
            protected override void OnMouseLeave(EventArgs e){over=false;Invalidate();base.OnMouseLeave(e);}
            protected override void OnPaint(PaintEventArgs e){e.Graphics.Clear(over&&Enabled?(light?Color.FromArgb(235,236,240):Color.FromArgb(45,48,57)):owner.surface);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;float x=Width/2f,y=Height/2f,r=owner.Px(5);Color ink=Enabled?(light?Color.FromArgb(44,47,54):Color.Gainsboro):(light?Color.FromArgb(178,181,188):Color.FromArgb(94,98,108));using(var pen=new Pen(ink,Math.Max(1,owner.Px(1)))){e.Graphics.DrawLine(pen,x-r,y,x+r,y);e.Graphics.DrawLines(pen,new PointF[]{new PointF(x,y-r),new PointF(x-r,y),new PointF(x,y+r)});}if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(2,2,Width-4,Height-4));}
        }
    }
    [STAThread] static void Main(string[] args){SetProcessDpiAwarenessContext(new IntPtr(-4));Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);bool test=false;
#if SELF_TEST
        test=Array.IndexOf(args,"--smoke-test")>=0;
#endif
        string reports=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"test-output");int index=Array.IndexOf(args,"--report-dir");if(index>=0&&index+1<args.Length)reports=Path.GetFullPath(args[index+1]);if(test)Directory.CreateDirectory(reports);Application.Run(new PlayerWindow(test,reports));}
}



