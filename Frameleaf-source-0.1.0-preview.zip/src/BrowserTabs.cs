﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

internal sealed partial class PlayerWindow {
    sealed class BrowserTab {
        public readonly WebView2 View;
        public string Title="新标签";
        public bool Closed,HiddenMuted;
        public Task Ready;
        public BrowserTab(WebView2 view){View=view;}
    }
    [DataContract] sealed class TabMessage {
        [DataMember] public string action {get;set;}
        [DataMember] public string url {get;set;}
        [DataMember] public bool background {get;set;}
    }
    readonly List<BrowserTab> tabs=new List<BrowserTab>();
    readonly Panel browserHost=new Panel();
    readonly BrowserTabBar tabbar;
    BrowserTab activeTab;
    CoreWebView2Environment browserEnvironment;
    bool closing;

    protected override void OnFormClosed(FormClosedEventArgs e){closing=true;foreach(var tab in tabs.ToArray()){tab.Closed=true;tab.View.Dispose();}base.OnFormClosed(e);}
    bool Live(BrowserTab tab){return !closing&&!IsDisposed&&!tab.Closed&&!tab.View.IsDisposed;}
    bool AllowedPage(string value){Uri uri;return Uri.TryCreate(value,UriKind.Absolute,out uri)&&(uri.Scheme=="https"||uri.Scheme=="http");}
    bool TrustedSource(string value){Uri uri;return Uri.TryCreate(value,UriKind.Absolute,out uri)&&(uri.Scheme=="https"||uri.Scheme=="http")&&(uri.Host=="bilibili.com"||uri.Host.EndsWith(".bilibili.com",StringComparison.OrdinalIgnoreCase));}
    async Task InitializeBrowser(BrowserTab tab,string address){
        WebView2 view=tab.View;
        view.KeyDown+=HandleShellKey;
        await view.EnsureCoreWebView2Async(browserEnvironment);if(!Live(tab))return;
        var core=view.CoreWebView2;
        view.ZoomFactor=Math.Max(.5,Math.Min(2,settings.Zoom));
        view.ZoomFactorChanged+=delegate{if(activeTab==tab)SaveSettings();};
        core.Settings.IsStatusBarEnabled=false;
        await core.AddScriptToExecuteOnDocumentCreatedAsync(File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PageBehavior.js")));
        if(!Live(tab))return;
        core.IsMuted=activeTab!=tab;
        core.HistoryChanged+=delegate{if(Live(tab)&&activeTab==tab)titlebar.UpdateNavigation();};
        core.DocumentTitleChanged+=delegate{if(!Live(tab))return;string title=core.DocumentTitle;bool isHome=core.Source==Home;tab.Title=isHome?"首页":string.IsNullOrWhiteSpace(title)?"新标签":title.Replace("_哔哩哔哩_bilibili","").Replace("_bilibili","");tabbar.RefreshTabs();if(activeTab==tab)Text=tab.Title+" · "+AppName;};
        core.NewWindowRequested+=async delegate(object sender,CoreWebView2NewWindowRequestedEventArgs e){e.Handled=true;if(!Live(tab)||!AllowedPage(e.Uri))return;await OpenRequestedTab(e.Uri,true);};
        core.WebMessageReceived+=async delegate(object sender,CoreWebView2WebMessageReceivedEventArgs e){
            if(!Live(tab)||!TrustedSource(e.Source))return;TabMessage message;
            try{using(var stream=new MemoryStream(Encoding.UTF8.GetBytes(e.WebMessageAsJson)))message=(TabMessage)new DataContractJsonSerializer(typeof(TabMessage)).ReadObject(stream);}catch{return;}
            if(message!=null&&message.action=="open-tab"&&AllowedPage(message.url))await OpenRequestedTab(message.url,!message.background);
        };
        core.ContainsFullScreenElementChanged+=async delegate{
            if(!Live(tab))return;
            if(core.ContainsFullScreenElement){if(activeTab!=tab){try{await core.ExecuteScriptAsync("document.exitFullscreen().catch(()=>{})");}catch{}return;}if(!fullscreen){fullscreenFromPage=true;SetFullscreen(true);}}
            else if(activeTab==tab&&fullscreenFromPage){fullscreenFromPage=false;SetFullscreen(false);}
        };
        core.NavigationCompleted+=async delegate(object sender,CoreWebView2NavigationCompletedEventArgs e){
            if(!Live(tab))return;
            if(activeTab==tab){titlebar.UpdateNavigation();if(!e.IsSuccess)Text=AppName+" · 连接失败，按 F5 重试";}
            else await PauseTab(tab);
#if SELF_TEST
            if(smoke&&!testing){testing=true;try{await Task.Delay(6500);await Verify(e.IsSuccess);}catch(Exception ex){File.WriteAllText(Path.Combine(reportDir,"test-error.txt"),ex.ToString());Close();}}
#endif
        };
        view.Source=new Uri(address);if(activeTab==tab)titlebar.UpdateNavigation();
    }
    async Task OpenRequestedTab(string address,bool activate){try{await CreateTabAsync(address,activate);}catch(Exception ex){if(!closing)MessageBox.Show("页面打开失败，可稍后重试。\n"+ex.Message,AppName);}}
    async Task<BrowserTab> CreateTabAsync(string address,bool activate){
        if(browserEnvironment==null||closing)return null;
        var view=new WebView2(){Dock=DockStyle.Fill,DefaultBackgroundColor=Color.White,Visible=false};
        var tab=new BrowserTab(view);tab.Title=address==Home?"首页":"正在加载…";tabs.Add(tab);browserHost.Controls.Add(view);
        if(activate)ActivateTab(tab);else tabbar.RefreshTabs();
        try{tab.Ready=InitializeBrowser(tab,address);await tab.Ready;return tab;}
        catch{if(!Live(tab))return null;if(Live(tab)){tabs.Remove(tab);tab.Closed=true;browserHost.Controls.Remove(view);view.Dispose();if(activeTab==tab&&tabs.Count>0)ActivateTab(tabs[0]);tabbar.RefreshTabs();}throw;}
    }
    async Task PauseTab(BrowserTab tab){
        if(!Live(tab)||tab.View.CoreWebView2==null)return;
        try{
            var core=tab.View.CoreWebView2;
            if(!core.IsMuted)tab.HiddenMuted=false;
            core.IsMuted=true;
            if(core.ContainsFullScreenElement)await core.ExecuteScriptAsync("document.exitFullscreen().catch(()=>{})");
            await core.ExecuteScriptAsync("window.__biliTabsSetActive&&window.__biliTabsSetActive(false);document.querySelectorAll('video,audio').forEach(v=>v.pause())");
        }catch{}
    }
    async Task ResumeTab(BrowserTab tab){
        if(!Live(tab)||activeTab!=tab||tab.View.CoreWebView2==null)return;
        try{tab.View.CoreWebView2.IsMuted=tab.HiddenMuted;await tab.View.CoreWebView2.ExecuteScriptAsync("window.__biliTabsSetActive&&window.__biliTabsSetActive(true)");}catch{}
    }
    async void PauseInBackground(BrowserTab tab){await PauseTab(tab);}
    async void ResumeInBackground(BrowserTab tab){await ResumeTab(tab);}
    void ActivateTab(BrowserTab tab){
        if(tab==null||!Live(tab))return;
        var previous=activeTab;
        if(previous!=tab){
            if(fullscreen){fullscreenFromPage=false;SetFullscreen(false);}
            activeTab=tab;
            if(previous!=null&&Live(previous)){
                if(previous.View.CoreWebView2!=null){previous.HiddenMuted=previous.View.CoreWebView2.IsMuted;previous.View.CoreWebView2.IsMuted=true;}
                PauseInBackground(previous);previous.View.Visible=false;
            }
        }
        tab.View.Visible=true;tab.View.BringToFront();ResumeInBackground(tab);tab.View.Focus();Text=tab.Title+" · "+AppName;titlebar.UpdateNavigation();tabbar.RefreshTabs();
    }
    async Task CloseTabAsync(BrowserTab tab){
        if(tab==null||!Live(tab))return;
        if(tabs.Count==1){await CreateTabAsync(Home,true);if(!Live(tab))return;}
        int index=tabs.IndexOf(tab);
        if(activeTab==tab)ActivateTab(tabs[index>0?index-1:1]);
        tab.Closed=true;tabs.Remove(tab);browserHost.Controls.Remove(tab.View);tab.View.Dispose();tabbar.RefreshTabs();
    }
    sealed class BrowserTabBar:Control {
        readonly PlayerWindow owner;
        readonly Button add=new TabGlyphButton(false),overflow=new TabGlyphButton(true);
        readonly List<TabItem> items=new List<TabItem>();
        readonly ContextMenuStrip tabList=new ContextMenuStrip();
        bool updating;
        int first;
        public BrowserTabBar(PlayerWindow form){owner=form;DoubleBuffered=true;BackColor=form.surface;SetStyle(ControlStyles.ResizeRedraw,true);
            add.Text="+";add.AccessibleName="新建标签";add.Click+=async delegate{await owner.OpenRequestedTab(Home,true);};StyleButton(add);Controls.Add(add);
            overflow.Text="⌄";overflow.AccessibleName="全部标签";StyleButton(overflow);overflow.Click+=delegate{tabList.Items.Clear();foreach(var tab in owner.tabs){var selected=tab;var item=new ToolStripMenuItem(tab.Title){Checked=tab==owner.activeTab};item.Click+=delegate{owner.ActivateTab(selected);};tabList.Items.Add(item);}tabList.Show(overflow,new Point(0,overflow.Height));};Controls.Add(overflow);
        }
        static void StyleButton(Button b){b.FlatStyle=FlatStyle.Flat;b.FlatAppearance.BorderSize=0;b.Cursor=Cursors.Hand;b.TabStop=true;b.UseVisualStyleBackColor=false;b.BackColor=Color.Transparent;b.ForeColor=Color.FromArgb(110,115,125);}
        public bool ActiveTabReachable {get{var item=items.Find(i=>i.Tab==owner.activeTab);return item!=null&&item.Visible;}}
        public bool OverflowAvailable {get{return overflow.Visible;}}
        public bool NewTabButtonAvailable {get{return add.Visible&&add.Width>0&&add.Right<=Width;}}
        public void RefreshTabs(){if(updating||owner==null||IsDisposed)return;updating=true;
            try{
                foreach(var item in items.ToArray())if(!owner.tabs.Contains(item.Tab)){Controls.Remove(item);item.Dispose();items.Remove(item);}
                foreach(var tab in owner.tabs){var item=items.Find(i=>i.Tab==tab);if(item==null){item=new TabItem(owner,tab);items.Add(item);Controls.Add(item);}item.UpdateTitle();}
                int pad=owner.Px(12),gap=owner.Px(4),button=owner.Px(32),h=owner.Px(35),available=Math.Max(owner.Px(80),Width-2*pad-button-gap);
                int count=owner.tabs.Count;bool more=count*owner.Px(104)>available;int visible=more?Math.Max(1,(available-button-gap)/owner.Px(104)):Math.Max(1,count);
                overflow.Visible=more;if(!more)first=0;else{int selected=owner.tabs.IndexOf(owner.activeTab);first=Math.Max(0,Math.Min(first,count-visible));if(selected<first)first=selected;else if(selected>=first+visible)first=selected-visible+1;}
                int width=Math.Min(owner.Px(224),Math.Max(owner.Px(80),(available-(more?button+gap:0))/visible-gap));
                int x=pad;foreach(var item in items){int index=owner.tabs.IndexOf(item.Tab);item.Visible=index>=first&&index<first+visible;if(item.Visible){item.Bounds=new Rectangle(x,Height-h,width,h);x+=width+gap;item.Invalidate();}}
                add.Bounds=new Rectangle(x,Math.Max(0,(Height-button)/2),button,button);if(more)overflow.Bounds=new Rectangle(x+button+gap,Math.Max(0,(Height-button)/2),button,button);
            }finally{updating=false;}Invalidate();
        }
        protected override void OnResize(EventArgs e){base.OnResize(e);RefreshTabs();}
        protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);using(var pen=new Pen(Color.FromArgb(232,234,238)))e.Graphics.DrawLine(pen,0,Height-1,Width,Height-1);}
        sealed class TabGlyphButton:Button{
            readonly bool list;public TabGlyphButton(bool value){list=value;SetStyle(ControlStyles.OptimizedDoubleBuffer,true);}
            protected override void OnPaint(PaintEventArgs e){e.Graphics.Clear(BackColor==Color.Transparent?Parent.BackColor:BackColor);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;float x=Width/2f,y=Height/2f,r=Width/6f;using(var pen=new Pen(Color.FromArgb(105,110,120),1.3f)){if(list)e.Graphics.DrawLines(pen,new PointF[]{new PointF(x-r,y-r/2),new PointF(x,y+r/2),new PointF(x+r,y-r/2)});else{e.Graphics.DrawLine(pen,x-r,y,x+r,y);e.Graphics.DrawLine(pen,x,y-r,x,y+r);}}if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(2,2,Width-4,Height-4));}
        }
        sealed class TabItem:Panel {
            readonly PlayerWindow owner;public readonly BrowserTab Tab;
            readonly Button select=new Button(),close=new Button();readonly ToolTip tip=new ToolTip();
            public TabItem(PlayerWindow form,BrowserTab tab){owner=form;Tab=tab;DoubleBuffered=true;select.TextAlign=ContentAlignment.MiddleLeft;StyleButton(select);StyleButton(close);select.Click+=delegate{owner.ActivateTab(Tab);};select.MouseUp+=async delegate(object s,MouseEventArgs e){if(e.Button==MouseButtons.Middle)await owner.CloseTabAsync(Tab);};close.Text="×";close.Click+=async delegate{await owner.CloseTabAsync(Tab);};Controls.Add(select);Controls.Add(close);}
            public void UpdateTitle(){select.AccessibleName=Tab.Title;close.AccessibleName="关闭 "+Tab.Title;tip.SetToolTip(select,Tab.Title);BackColor=Tab==owner.activeTab?Color.White:owner.surface;select.BackColor=BackColor;close.BackColor=BackColor;select.ForeColor=Tab==owner.activeTab?Color.FromArgb(42,44,50):Color.FromArgb(125,130,140);select.Invalidate();}
            protected override void OnLayout(LayoutEventArgs e){base.OnLayout(e);int c=owner.Px(26);if(select!=null)select.Bounds=new Rectangle(owner.Px(7),0,Math.Max(0,Width-c-owner.Px(11)),Math.Max(0,Height-owner.Px(3)));if(close!=null)close.Bounds=new Rectangle(Math.Max(0,Width-c-owner.Px(3)),owner.Px(5),c,Math.Max(0,Height-owner.Px(11)));}
            protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);if(Tab==owner.activeTab)using(var b=new SolidBrush(Color.FromArgb(82,105,218)))e.Graphics.FillRectangle(b,owner.Px(12),Height-owner.Px(2),Math.Max(1,Width-owner.Px(24)),owner.Px(2));}
            protected override void Dispose(bool disposing){if(disposing)tip.Dispose();base.Dispose(disposing);}
            // Native button keeps keyboard/accessibility behavior; title drawing truncates long page names.
            protected override void OnCreateControl(){base.OnCreateControl();select.Paint+=delegate(object sender,PaintEventArgs e){e.Graphics.Clear(select.BackColor);int iconSize=owner.Px(13);e.Graphics.DrawIcon(owner.Icon,new Rectangle(owner.Px(3),(select.Height-iconSize)/2,iconSize,iconSize));Rectangle rect=new Rectangle(owner.Px(23),0,Math.Max(0,select.Width-owner.Px(27)),select.Height);using(var font=new Font("Microsoft YaHei UI",9f))TextRenderer.DrawText(e.Graphics,Tab.Title,font,rect,select.ForeColor,TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);};}
        }
    }
}
