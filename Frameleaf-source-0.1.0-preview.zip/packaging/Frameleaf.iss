#define AppName "Frameleaf Preview"
#define AppVersion "0.1.0"

[Setup]
AppId={{F69B7C30-D9BB-4B47-A415-9181DD4B3F78}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Frameleaf contributors
DefaultDirName={localappdata}\Programs\FrameleafPreview
DefaultGroupName=Frameleaf Preview
PrivilegesRequired=lowest
ArchitecturesAllowed=x64os
ArchitecturesInstallIn64BitMode=x64os
MinVersion=10.0.18362
OutputDir=..\out\release
OutputBaseFilename=Frameleaf-Setup-0.1.0-preview-x64
SetupIconFile=..\assets\Frameleaf.ico
UninstallDisplayIcon={app}\Frameleaf.exe
UninstallDisplayName=Frameleaf Preview
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
LicenseFile=..\LICENSE
CloseApplications=yes
RestartApplications=no
VersionInfoVersion=0.1.0.0
VersionInfoDescription=Frameleaf public preview installer

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a Frameleaf Preview desktop shortcut"; Flags: unchecked
Name: "startmenuicon"; Description: "Create Start menu shortcuts"; Flags: unchecked

[Files]
Source: "..\out\Frameleaf-win-x64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\licenses\Inno-Setup-LICENSE.txt"; DestDir: "{app}\licenses"; Flags: ignoreversion

[Icons]
Name: "{autodesktop}\Frameleaf Preview"; Filename: "{app}\Frameleaf.exe"; Tasks: desktopicon
Name: "{group}\Frameleaf Preview"; Filename: "{app}\Frameleaf.exe"; Tasks: startmenuicon
Name: "{group}\Uninstall Frameleaf Preview"; Filename: "{uninstallexe}"; Tasks: startmenuicon

[Run]
Filename: "{app}\Frameleaf.exe"; Description: "Open Frameleaf Preview"; Flags: nowait postinstall skipifsilent unchecked

[Code]
function HasWebView2(): Boolean;
var
  Version: String;
  Key: String;
begin
  Key := 'Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}';
  Result := False;
  if RegQueryStringValue(HKLM32, Key, 'pv', Version) then
    Result := (Version <> '') and (Version <> '0.0.0.0');
  if not Result then
    if RegQueryStringValue(HKCU, Key, 'pv', Version) then
      Result := (Version <> '') and (Version <> '0.0.0.0');
end;

function InitializeSetup(): Boolean;
var
  Release: Cardinal;
begin
  Result := RegQueryDWordValue(HKLM32, 'Software\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', Release);
  if Result then Result := Release >= 528040;
  if not Result then
    MsgBox('Frameleaf requires .NET Framework 4.8. Obtain it from Microsoft, then run this installer again:' + #13#10 + 'https://dotnet.microsoft.com/download/dotnet-framework/net48', mbError, MB_OK);
  if Result and (not HasWebView2()) then begin
    Result := False;
    MsgBox('Frameleaf requires Microsoft WebView2 Evergreen Runtime. Obtain it from Microsoft, then run this installer again:' + #13#10 + 'https://developer.microsoft.com/microsoft-edge/webview2/', mbError, MB_OK);
  end;
end;
