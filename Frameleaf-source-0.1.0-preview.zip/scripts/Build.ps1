﻿[CmdletBinding()]
param([switch]$TestBuild)
$ErrorActionPreference='Stop'
$repo=Split-Path -Parent $PSScriptRoot
$lock=Get-Content -LiteralPath (Join-Path $repo 'dependency-lock.json') -Raw | ConvertFrom-Json
$cache=Join-Path $repo '.cache'
New-Item -ItemType Directory -Path $cache -Force | Out-Null
$package=Join-Path $cache 'webview2.nupkg'
if(-not(Test-Path -LiteralPath $package)){
  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -UseBasicParsing -Uri $lock.webview2.url -OutFile $package
}
if((Get-FileHash -LiteralPath $package -Algorithm SHA512).Hash -ne $lock.webview2.sha512){throw 'WebView2 package checksum mismatch. Remove .cache/webview2.nupkg and retry.'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sdk=Join-Path $cache 'webview2'
New-Item -ItemType Directory -Path $sdk -Force | Out-Null
$sdkPrefix=[IO.Path]::GetFullPath($sdk)+[IO.Path]::DirectorySeparatorChar
$zip=[IO.Compression.ZipFile]::OpenRead($package)
try{
  foreach($entry in $zip.Entries){
    $path=[IO.Path]::GetFullPath((Join-Path $sdk $entry.FullName))
    if(-not $path.StartsWith($sdkPrefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe package entry'}
    if($entry.FullName.EndsWith('/')){New-Item -ItemType Directory -Path $path -Force | Out-Null;continue}
    New-Item -ItemType Directory -Path (Split-Path -Parent $path) -Force | Out-Null
    $inputStream=$entry.Open();$outputStream=[IO.File]::Create($path)
    try{$inputStream.CopyTo($outputStream)}finally{$outputStream.Dispose();$inputStream.Dispose()}
  }
}finally{$zip.Dispose()}
foreach($name in @('LICENSE.txt','NOTICE.txt')){
  $trackedName=if($name -eq 'LICENSE.txt'){'WebView2-LICENSE.txt'}else{'WebView2-NOTICE.txt'}
  $sourceHash=(Get-FileHash -LiteralPath (Join-Path $sdk $name)).Hash
  $trackedHash=(Get-FileHash -LiteralPath (Join-Path $repo ('licenses/'+$trackedName))).Hash
  if($sourceHash -ne $trackedHash){throw ('Dependency legal notice changed: '+$name)}
}
& (Join-Path $PSScriptRoot 'MakeIcon.ps1')
$folder=if($TestBuild){'out/smoke-app'}else{'out/Frameleaf-win-x64'}
$output=Join-Path $repo $folder
New-Item -ItemType Directory -Path $output -Force | Out-Null
foreach($name in @('Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.WinForms.dll')){Copy-Item -LiteralPath (Join-Path $sdk ('lib/net462/'+$name)) -Destination $output -Force}
Copy-Item -LiteralPath (Join-Path $sdk 'runtimes/win-x64/native/WebView2Loader.dll') -Destination $output -Force
foreach($name in @('PageBehavior.js','Frameleaf.exe.config','Frameleaf.json')){Copy-Item -LiteralPath (Join-Path $repo ('src/'+$name)) -Destination $output -Force}
Copy-Item -LiteralPath (Join-Path $repo 'assets/Frameleaf.ico'),(Join-Path $repo 'LICENSE'),(Join-Path $repo 'THIRD_PARTY_NOTICES.md'),(Join-Path $repo 'README.md'),(Join-Path $repo 'README.en.md'),(Join-Path $repo 'PRIVACY.md'),(Join-Path $repo 'SECURITY.md'),(Join-Path $repo 'CONTRIBUTING.md'),(Join-Path $repo 'CHANGELOG.md') -Destination $output -Force
New-Item -ItemType Directory -Path (Join-Path $output 'licenses'),(Join-Path $output 'assets'),(Join-Path $output 'docs') -Force | Out-Null
Copy-Item -Path (Join-Path $repo 'docs/*.md') -Destination (Join-Path $output 'docs') -Force
Copy-Item -LiteralPath (Join-Path $repo 'assets/Frameleaf.svg'),(Join-Path $repo 'assets/window-preview.svg') -Destination (Join-Path $output 'assets') -Force
Copy-Item -LiteralPath (Join-Path $repo 'licenses/WebView2-LICENSE.txt'),(Join-Path $repo 'licenses/WebView2-NOTICE.txt'),(Join-Path $repo 'licenses/Inno-Setup-LICENSE.txt') -Destination (Join-Path $output 'licenses') -Force
$compiler=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
if(-not(Test-Path -LiteralPath $compiler)){throw '.NET Framework 4.8 on Windows x64 is required.'}
$arguments=@('/nologo','/nowarn:0429','/target:winexe','/platform:x64','/debug-',('/out:'+(Join-Path $output 'Frameleaf.exe')),('/win32icon:'+(Join-Path $repo 'assets/Frameleaf.ico')),('/win32manifest:'+(Join-Path $repo 'src/app.manifest')),'/reference:System.dll','/reference:System.Core.dll','/reference:System.Drawing.dll','/reference:System.Windows.Forms.dll','/reference:System.Runtime.Serialization.dll',('/reference:'+(Join-Path $output 'Microsoft.Web.WebView2.Core.dll')),('/reference:'+(Join-Path $output 'Microsoft.Web.WebView2.WinForms.dll')),(Join-Path $repo 'src/PlayerWindow.cs'),(Join-Path $repo 'src/BrowserTabs.cs'))
if($TestBuild){$arguments+='/define:SELF_TEST';$arguments+=(Join-Path $repo 'tests/SmokeTests.cs')}
& $compiler @arguments
if($LASTEXITCODE -ne 0){throw 'Compilation failed.'}
Write-Output ('Built '+$folder+'/Frameleaf.exe')
