$ErrorActionPreference='Stop'
$repo=Split-Path -Parent $PSScriptRoot
$excluded='[\\/](out|\.cache|\.git|\.local|\.review)[\\/]'
$files=Get-ChildItem -LiteralPath $repo -Recurse -File -Force | Where-Object {$_.FullName -notmatch $excluded}
$errors=New-Object Collections.Generic.List[string]
foreach($file in $files){
  if($file.Name -match '^(Cookies(?:-journal)?|History(?:-journal)?|Login Data.*|Local State|Preferences|window-settings\.json|\.env(?:\..*)?)$' -or $file.Extension -in @('.exe','.dll','.pdb','.nupkg','.log','.sqlite','.db','.zip')){$errors.Add('Unexpected private/generated file: '+$file.Name)}
  if($file.FullName -match '[\\/](Profile|EBWebView|test-profile|test-data|Cache)[\\/]'){$errors.Add('Browser data directory found')}
  if($file.Extension -in @('.cs','.js','.ps1','.md','.json','.yml','.config','.manifest','.svg')){
    $text=Get-Content -LiteralPath $file.FullName -Raw
    if($text -match '(?i)[A-Z]:[\\/]Users[\\/][^\s"''<>]+'){$errors.Add('Personal absolute path found: '+$file.Name)}
    if($text -match '(?i)(gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----)'){$errors.Add('Possible credential found: '+$file.Name)}
    if($file.DirectoryName -eq (Join-Path $repo 'src')){
      if($text -match 'ClientPromoFilter|IsClientDownload|data-local-client-hidden|__douyinClientFilter|__bilibiliClientFilter|BilibiliWebStudio|DouyinWebStudio|A18221C7|6BF211B7'){$errors.Add('Private edition identity or promotion filtering found in '+$file.Name)}
    }
  }
}
$release=Join-Path $repo 'out/Frameleaf-win-x64'
if(Test-Path -LiteralPath (Join-Path $release 'Frameleaf.exe')){
  $bytes=[IO.File]::ReadAllBytes((Join-Path $release 'Frameleaf.exe'))
  $strings=[Text.Encoding]::Unicode.GetString($bytes)
  $names=[Text.Encoding]::ASCII.GetString($bytes)
  if($strings.Contains('minimal_tabs_smoke') -or $names.Contains('VerifyTabs') -or $names.Contains('SmokeTests')){$errors.Add('Self-test implementation found in release executable')}
}
if($errors.Count){throw ($errors -join [Environment]::NewLine)}
Write-Output ('Public source check passed ('+$files.Count+' files; generated folders excluded).')
