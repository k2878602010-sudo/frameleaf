$ErrorActionPreference='Stop'
$repo=Split-Path -Parent $PSScriptRoot
Add-Type -AssemblyName System.Drawing
$sizes=@(16,24,32,48,64,128,256)
$images=@()
foreach($size in $sizes){
  $bitmap=New-Object Drawing.Bitmap($size,$size)
  $graphics=[Drawing.Graphics]::FromImage($bitmap)
  $graphics.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $graphics.ScaleTransform($size/256.0,$size/256.0)
  $graphics.Clear([Drawing.Color]::Transparent)
  $round=New-Object Drawing.Drawing2D.GraphicsPath
  $round.AddArc(8,8,64,64,180,90);$round.AddArc(184,8,64,64,270,90);$round.AddArc(184,184,64,64,0,90);$round.AddArc(8,184,64,64,90,90);$round.CloseFigure()
  $blue=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(82,105,218))
  $back=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(165,178,239))
  $paper=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(249,250,255))
  $graphics.FillPath($blue,$round)
  $graphics.FillRectangle($back,51,53,137,119)
  $graphics.FillRectangle($paper,69,73,137,119)
  $pen=New-Object Drawing.Pen([Drawing.Color]::FromArgb(82,105,218),8)
  $graphics.DrawLine($pen,94,104,180,104);$graphics.DrawLine($pen,94,127,165,127);$graphics.DrawLine($pen,94,150,149,150)
  $stream=New-Object IO.MemoryStream
  $bitmap.Save($stream,[Drawing.Imaging.ImageFormat]::Png)
  $images+=,[PSCustomObject]@{Size=$size;Bytes=$stream.ToArray()}
  if($size -eq 256){$bitmap.Save((Join-Path $repo 'assets/Frameleaf.png'),[Drawing.Imaging.ImageFormat]::Png)}
  $stream.Dispose();$pen.Dispose();$paper.Dispose();$back.Dispose();$blue.Dispose();$round.Dispose();$graphics.Dispose();$bitmap.Dispose()
}
$output=[IO.File]::Create((Join-Path $repo 'assets/Frameleaf.ico'))
$writer=New-Object IO.BinaryWriter($output)
try{
  $writer.Write([uint16]0);$writer.Write([uint16]1);$writer.Write([uint16]$images.Count)
  $offset=6+16*$images.Count
  foreach($img in $images){$dimension=if($img.Size -eq 256){0}else{$img.Size};$writer.Write([byte]$dimension);$writer.Write([byte]$dimension);$writer.Write([byte]0);$writer.Write([byte]0);$writer.Write([uint16]1);$writer.Write([uint16]32);$writer.Write([uint32]$img.Bytes.Length);$writer.Write([uint32]$offset);$offset+=$img.Bytes.Length}
  foreach($img in $images){$writer.Write([byte[]]$img.Bytes)}
}finally{$writer.Dispose();$output.Dispose()}
