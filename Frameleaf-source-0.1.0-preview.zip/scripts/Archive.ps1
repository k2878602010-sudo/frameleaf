$ErrorActionPreference='Stop'
$repo=Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'CheckPublic.ps1')
$release=Join-Path $repo 'out/release'
New-Item -ItemType Directory -Path $release -Force | Out-Null
$roots=@('src','scripts','tests','assets','docs','licenses','packaging','.github','README.md','README.en.md','LICENSE','PRIVACY.md','THIRD_PARTY_NOTICES.md','SECURITY.md','CONTRIBUTING.md','CHANGELOG.md','dependency-lock.json','.gitignore','.gitattributes')
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
function CreateArchive([string]$destination,[string]$base,[string[]]$paths){
  if(Test-Path -LiteralPath $destination){Remove-Item -LiteralPath $destination}
  $zip=[IO.Compression.ZipFile]::Open($destination,[IO.Compression.ZipArchiveMode]::Create)
  try{
    foreach($name in $paths){
      $item=Get-Item -LiteralPath (Join-Path $base $name) -Force
      $files=if($item.PSIsContainer){Get-ChildItem -LiteralPath $item.FullName -Recurse -File -Force}else{@($item)}
      foreach($file in $files){$relative=$file.FullName.Substring($base.Length).TrimStart([char[]]'\/').Replace('\','/');[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$relative,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    }
  }finally{$zip.Dispose()}
}
CreateArchive (Join-Path $release 'Frameleaf-source-0.1.0-preview.zip') $repo $roots
$portable=Join-Path $repo 'out/Frameleaf-win-x64'
if(-not(Test-Path -LiteralPath (Join-Path $portable 'Frameleaf.exe'))){throw 'Run scripts/Build.ps1 before creating the portable archive.'}
$portableRoots=@('Frameleaf.exe','Frameleaf.exe.config','Frameleaf.json','Frameleaf.ico','PageBehavior.js','Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.WinForms.dll','WebView2Loader.dll','LICENSE','THIRD_PARTY_NOTICES.md','README.md','README.en.md','PRIVACY.md','SECURITY.md','CONTRIBUTING.md','CHANGELOG.md','licenses','assets','docs')
CreateArchive (Join-Path $release 'Frameleaf-0.1.0-preview-win-x64.zip') $portable $portableRoots
$checksumLines=@()
foreach($file in Get-ChildItem -LiteralPath $release -File | Where-Object {$_.Extension -in @('.zip','.exe')}){$checksumLines+=((Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()+'  '+$file.Name)}
[IO.File]::WriteAllLines((Join-Path $release 'SHA256SUMS.txt'),[string[]]$checksumLines,[Text.Encoding]::ASCII)
Write-Output 'Source and portable archives created in out/release. No upload performed.'
