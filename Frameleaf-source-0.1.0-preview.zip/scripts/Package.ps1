[CmdletBinding()]
param([string]$Compiler)
$ErrorActionPreference='Stop'
$repo=Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'Build.ps1')
& (Join-Path $PSScriptRoot 'CheckPublic.ps1')
if(-not $Compiler){$command=Get-Command ISCC.exe -ErrorAction SilentlyContinue;if($command){$Compiler=$command.Source}}
if(-not $Compiler){foreach($folder in @(${env:ProgramFiles(x86)},$env:ProgramFiles)){if($folder){$candidate=Join-Path $folder 'Inno Setup 6/ISCC.exe';if(Test-Path -LiteralPath $candidate){$Compiler=$candidate;break}}}}
if(-not $Compiler -or -not(Test-Path -LiteralPath $Compiler)){throw 'Pass -Compiler with the path to an official Inno Setup ISCC.exe.'}
& $Compiler /Q (Join-Path $repo 'packaging/Frameleaf.iss')
if($LASTEXITCODE -ne 0){throw 'Installer compilation failed.'}
Write-Output 'Installer built in out/release. Nothing was installed.'
