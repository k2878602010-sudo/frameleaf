$ErrorActionPreference='Stop'
$repo=Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'Build.ps1') -TestBuild
$report=Join-Path $repo ('out/tests/'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $report -Force | Out-Null
$executable=Join-Path $repo 'out/smoke-app/Frameleaf.exe'
$process=Start-Process -FilePath $executable -ArgumentList @('--smoke-test','--report-dir',('"'+$report+'"')) -WindowStyle Hidden -PassThru
if(-not $process.WaitForExit(90000)){$process.Kill();throw 'UI self-test timed out.'}
$result=Join-Path $report 'test-result.txt'
if(-not(Test-Path -LiteralPath $result)){
  foreach($name in @('startup-error.txt','test-error.txt')){if(Test-Path -LiteralPath (Join-Path $report $name)){Get-Content -LiteralPath (Join-Path $report $name)}}
  throw 'UI self-test did not produce a report.'
}
$text=Get-Content -LiteralPath $result -Raw
if($text -match '(?m)^\w+=False$'){throw ('UI self-test failed: '+$text)}
if(Test-Path -LiteralPath (Join-Path $report 'test-error.txt')){throw 'UI self-test recorded an exception.'}
Write-Output $text
Write-Output 'UI self-test passed. Reports remain in ignored out/tests.'
