# Security

Frameleaf embeds websites in WebView2. Treat page content as untrusted. Native tab requests accept HTTP/HTTPS URLs; the Bilibili adapter's message handler checks the sending origin. The app does not expose local file access or developer account credentials to page scripts.

The browser runtime is an external prerequisite and receives its own updates from Microsoft. Do not disable browser sandboxing or certificate validation to work around a website problem.

If the repository Security page offers a private vulnerability reporting option, use it. Otherwise open a minimal issue requesting a private reporting channel, without including vulnerability details or sensitive data. Do not publish tokens, cookies, account QR codes, browser profiles or exploit details containing private information in a public issue.

Repository: https://github.com/k2878602010-sudo/frameleaf

Security reports and support logs must be reviewed locally before sharing. There is no automatic log upload.
