<img src="assets/Frameleaf.svg" width="64" height="64" alt="Frameleaf 图标：叠放的两页纸">

# 帧页 Frameleaf

一个轻量的 Windows 多标签网页视频窗口。独立窗口、独立页面、少一点打扰。

**v0.1.0-preview · 首个公开预览版。** 欢迎试用，并通过 [Issues](https://github.com/k2878602010-sudo/frameleaf/issues) 反馈体验。项目不宣称已完成商标检索或取得平台授权。

[English](README.en.md) · [构建说明](docs/BUILD.md) · [使用说明](docs/USAGE.md) · [隐私说明](PRIVACY.md)

![Frameleaf 界面示意图，非真实网页截图](assets/window-preview.svg)

## 能做什么

- 窄标题栏和多标签栏，支持新增、关闭、切换和查看全部标签。
- 每个标签独立保留当前页面、滚动位置和返回记录；同一程序中的标签共用登录状态。
- 切换标签时暂停上一页的媒体并静音，切回后由用户继续播放。
- F11 或网页视频全屏时隐藏顶部两栏，退出后恢复窗口。
- 支持窗口置顶、页面缩放、窗口大小与位置记忆，以及高清屏缩放。
- 首个网站适配为 B 站：点击视频在新标签打开，中键或 Ctrl+单击在后台打开。

默认首页是 `https://www.bilibili.com/`，可修改程序旁的 `Frameleaf.json`。其他网站可以通过基础窗口浏览，但没有承诺提供视频链接识别、兼容性或平台专项适配。

## 产品边界

Frameleaf 通过 Microsoft WebView2 加载原网站；它不代理、托管或重新分发网站视频。账户、会员权限和清晰度由原网站决定。

**公开版保留网站的客户端下载入口、推广浮层和广告。** 没有客户端推广过滤、广告过滤、会员解锁、受限内容绕过、视频提取或批量下载功能。多标签适配脚本用于链接打开方式和媒体暂停，不用于删除页面元素。

项目与哔哩哔哩、字节跳动及 Microsoft 均无官方隶属或背书关系。提及网站名称仅为说明适配范围；网站内容、名称和标识的权利归各自权利人。公开源码和免责声明不能代替平台授权，也不构成对所有使用方式合法性的保证。使用前请阅读相应网站条款，见 [发布边界说明](docs/PUBLISHING.md)。

## 下载与反馈

前往 [Releases](https://github.com/k2878602010-sudo/frameleaf/releases/tag/v0.1.0-preview) 下载：

- **便携版**：`Frameleaf-0.1.0-preview-win-x64.zip`，解压即可运行。
- **安装版**：`Frameleaf-Setup-0.1.0-preview-x64.exe`，独立安装、可卸载。
- **源码包**与 `SHA256SUMS.txt` 一并提供。

欢迎提交 [使用反馈](https://github.com/k2878602010-sudo/frameleaf/issues/new?template=feedback.md) 或 [问题报告](https://github.com/k2878602010-sudo/frameleaf/issues/new?template=bug_report.md)。请告诉我你的 Windows 版本、显示缩放比例，以及哪些细节好用或需要改进；分享前移除账号、二维码和个人内容。

## 运行

- Windows 10 1903 及以上或 Windows 11，Intel/AMD x64；不提供 ARM64 原生版本。
- .NET Framework 4.8 和 [Microsoft WebView2 Evergreen Runtime](https://developer.microsoft.com/microsoft-edge/webview2/)。
- 便携包解压后运行 `Frameleaf.exe`。也可使用独立的 Frameleaf Preview 安装包。
- 安装程序不静默下载或安装第三方运行库；缺少运行库时会提示到微软官方页面获取。
- 当前构建没有代码签名，Windows 可能显示未知发布者；请核对将来正式发布时提供的 SHA-256。

公开版使用 `%LOCALAPPDATA%\Frameleaf.PublicPreview` 保存登录数据和窗口设置，与本地定制版的数据目录独立。首次使用需要自行登录。退出后不恢复上次的页面标签；登录状态和窗口设置保留。

## 从源码构建

Windows PowerShell 5.1 或 PowerShell 7，在仓库根目录执行：

```powershell
powershell -NoProfile -File .\scripts\Build.ps1
powershell -NoProfile -File .\scripts\CheckPublic.ps1
```

首次构建从 NuGet 官方源获取固定版本 WebView2 SDK，并校验仓库记录的 SHA-512。不需要访问作者电脑上的程序、路径或缓存，也不要求安装完整 .NET SDK。构建结果位于 `out\Frameleaf-win-x64`。

完整构建、测试、安装包和源代码归档方法见 [BUILD.md](docs/BUILD.md)。源码中包含微软组件原始许可和通知；构建与打包时会继续携带。

## 快捷键

| 操作 | 快捷键 |
| --- | --- |
| 新建 / 关闭当前标签 | Ctrl+T / Ctrl+W |
| 下一个 / 上一个标签 | Ctrl+Tab / Ctrl+Shift+Tab |
| 返回 / 前进 | Alt+← / Alt+→ |
| 首页 / 刷新 | Alt+Home / F5 |
| 全屏 / 退出全屏 | F11 / Esc |
| 切换置顶 | Ctrl+Shift+T |

## 参与和许可

欢迎报告可复现的问题。提交日志或截图前，请移除账号、二维码、Cookie、个人浏览记录及其他敏感信息。参见 [CONTRIBUTING.md](CONTRIBUTING.md) 和 [SECURITY.md](SECURITY.md)。

项目代码及原创图形采用 [MIT License](LICENSE)。第三方组件独立遵循其许可，见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。图标为仓库中的几何图形源文件与生成脚本，不使用平台 Logo。界面图是项目绘制的示意图，不包含平台网页或第三方视频截图。

设计方向受 [Pake](https://github.com/tw93/Pake) 等网页桌面化工具启发。本项目以 C#、WinForms 和 WebView2 实现；当前依赖清单不含 Pake / Tauri / Electron。后续若引入第三方代码，应单独核对并保留其许可，不能套用本项目 MIT 声明覆盖它。
