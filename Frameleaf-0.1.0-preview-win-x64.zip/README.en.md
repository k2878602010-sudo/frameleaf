# Frameleaf

A lightweight tabbed web-video window for Windows, built with C#, WinForms and Microsoft WebView2.

**v0.1.0-preview: first public preview.** [Downloads](https://github.com/k2878602010-sudo/frameleaf/releases/tag/v0.1.0-preview) · [Feedback](https://github.com/k2878602010-sudo/frameleaf/issues). The project does not claim trademark clearance or platform authorization.

[中文说明](README.md)

Features include independent tab history, new/close/switch controls, background media pause and mute, fullscreen chrome hiding, window pinning, zoom and high-DPI support. The first site adapter targets Bilibili video links. Other websites have basic browsing support without site-specific guarantees.

The public build preserves website advertisements and client-download promotions. It provides no paywall bypass, video extraction, bulk download, content redistribution or account automation. It loads the original website directly. Site permissions and terms still apply; this project is unofficial and does not claim platform authorization.

Requirements: Windows 10 1903+ / Windows 11 x64, .NET Framework 4.8, and the Microsoft WebView2 Evergreen Runtime. The preview uses a separate local profile under `%LOCALAPPDATA%\Frameleaf.PublicPreview` and does not reuse profiles from any customized build.

```powershell
powershell -NoProfile -File .\scripts\Build.ps1
powershell -NoProfile -File .\scripts\CheckPublic.ps1
```

The build restores the pinned WebView2 package from the official NuGet source and checks SHA-512. It does not depend on files from the author's installation. Build output and dependency caches are excluded from the source archive.

See [build instructions](docs/BUILD.md), [privacy](PRIVACY.md), [publication boundaries](docs/PUBLISHING.md), [security](SECURITY.md), and [third-party notices](THIRD_PARTY_NOTICES.md). Project code and original graphics are MIT licensed; third-party software retains its own terms.
