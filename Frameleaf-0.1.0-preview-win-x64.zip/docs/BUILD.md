# 构建、测试与归档

所有路径相对仓库根目录。脚本只在仓库的 `.cache`、`out` 和原创图标目录生成文件，不从旧版安装目录取依赖，也不部署或修改其他应用。

## 环境

- Windows x64，Windows PowerShell 5.1 或 PowerShell 7。
- .NET Framework 4.8；调用 Windows 自带 Framework C# 编译器，无需完整 .NET SDK。
- 首次构建联网访问 NuGet 官方源。包版本和 SHA-512 固定在 `dependency-lock.json`；版本更新必须一起更新校验值和第三方许可文件。
- 运行界面自检需要 WebView2 Evergreen Runtime、联网访问默认首页，以及未锁屏的交互式 Windows 桌面。

## 编译与检查

```powershell
powershell -NoProfile -File .\scripts\Build.ps1
powershell -NoProfile -File .\scripts\CheckPublic.ps1
```

产物：`out\Frameleaf-win-x64\Frameleaf.exe`。运行时资料不会写入源代码目录。若本机的包下载失败，应检查网络，不能为了绕过错误跳过校验或改用未知来源 DLL。

从 `out\Frameleaf-win-x64` 运行用于查看的版本，不需要先安装。它与原有定制程序使用不同的名称和数据目录。

## 界面与集成自检

```powershell
powershell -NoProfile -File .\scripts\Test.ps1
```

脚本编译 `SELF_TEST` 专用测试程序，使用独立资料目录，实际验证多标签、视频暂停、独立历史、共享网站 Cookie、全屏、缩放和菜单边缘。还会检查公开版保留客户端下载链接及页面元素。

测试会联网打开默认网站和测试链接，可能留下测试用浏览数据；全部位于被忽略的 `out\tests` 中。报告不应直接上传。发布程序不包含该测试实现，也不提供 `--smoke-test` 入口。CI 只做构建和静态公开检查，不声称代替本地的完整界面验证。

## 构建可选安装包

从 [Inno Setup 官方网站](https://jrsoftware.org/isdl.php)安装 Inno Setup，或传入官方编译器的完整路径：

```powershell
powershell -NoProfile -File .\scripts\Package.ps1 -Compiler "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
```

这是示例安装路径，不是依赖作者机器的路径。编译器也可通过 `Get-Command ISCC.exe` 或标准安装目录找到。

安装包使用独立的 Frameleaf Preview AppId、安装目录和开始菜单分组；桌面快捷方式默认不选中。它不包含生产版 B 站或抖音的安装标识、升级删除规则或个人资料。运行库须由使用者从微软获取，不静默补装。

安装包在 `out\release`，仅执行打包不会安装程序。

## 生成供审阅的源代码包和便携包

```powershell
powershell -NoProfile -File .\scripts\Archive.ps1
```

归档脚本先执行公开检查，然后从明确列出的源码文件与目录打包，生成：

- `out\release\Frameleaf-source-0.1.0-preview.zip`
- `out\release\Frameleaf-0.1.0-preview-win-x64.zip`
- `out\release\SHA256SUMS.txt`

源码包不包含 `.cache`、`out`、测试报告、登录资料、绝对路径审计记录或编译二进制。源码包与便携包用途不同：前者用于 GitHub 仓库，后者可供将来的 Release 附件。

这些脚本没有 `git push`、仓库创建、上传或发布功能。
