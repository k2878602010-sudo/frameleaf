# Third-party notices

## Microsoft WebView2 SDK

- Package: `Microsoft.Web.WebView2`, version `1.0.4258.31`.
- Source: https://www.nuget.org/packages/Microsoft.Web.WebView2/1.0.4258.31
- Exact download and SHA-512: `dependency-lock.json`.
- Unmodified license: `licenses/WebView2-LICENSE.txt`.
- Unmodified notices: `licenses/WebView2-NOTICE.txt`.

The core assembly, WinForms assembly and x64 loader are restored at build time, not committed to the source repository. Binary packages retain the above license and notice files. The build checks that tracked legal files match the pinned NuGet package.

## Microsoft .NET Framework and WebView2 Runtime

These are separately installed prerequisites. The project does not include a fixed browser engine, distribute the .NET runtime, or automatically accept their installation terms. They remain subject to Microsoft's terms and servicing policies.

## Inno Setup

Optional installer creation uses an independently installed, unmodified Inno Setup compiler. The repository does not redistribute the compiler. Installer creation retains its generated notices; an unmodified copy of its license is included in `licenses/Inno-Setup-LICENSE.txt` for the packaging tool acknowledgement.

Source: https://jrsoftware.org/isinfo.php

## Websites, names and graphics

Website content is not licensed by this repository's MIT license. Third-party names and marks remain with their owners. Frameleaf does not include platform icons or third-party content screenshots in its original artwork.

The icon SVG and equivalent PowerShell drawing script are project artwork under the MIT license. Package licenses do not grant any website access or content rights.
