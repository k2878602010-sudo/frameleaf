(() => {
  if (window.__biliTabsInstalled) return;
  window.__biliTabsInstalled = true;
  let active = !document.hidden;
  const pause = () => {
    const walk = root => {
      for (const media of root.querySelectorAll('video,audio')) media.pause();
      for (const node of root.querySelectorAll('*')) if (node.shadowRoot) walk(node.shadowRoot);
    };
    walk(document);
  };
  window.__biliTabsSetActive = value => { active = !!value; if (!active) pause(); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });
  document.addEventListener('play', event => { if (!active || document.hidden) event.target.pause(); }, true);
  if (window.top !== window || !/(^|\.)bilibili\.com$/i.test(location.hostname)) return;
  function open(event) {
    if ((event.type === 'click' && event.button !== 0) || (event.type === 'auxclick' && event.button !== 1)) return;
    const anchor = event.composedPath().find(node => node instanceof HTMLAnchorElement);
    if (!anchor || anchor.hasAttribute('download')) return;
    let url;
    try { url = new URL(anchor.href, location.href); } catch { return; }
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return;
    const video = /(^|\.)bilibili\.com$/i.test(url.hostname) && /^\/(video\/|bangumi\/play\/)/.test(url.pathname);
    const background = event.button === 1 || event.ctrlKey || event.metaKey;
    if (!video && !background) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    window.chrome.webview.postMessage({action:'open-tab', url:url.href, background});
  }
  window.addEventListener('click', open, true);
  window.addEventListener('auxclick', open, true);
})();
